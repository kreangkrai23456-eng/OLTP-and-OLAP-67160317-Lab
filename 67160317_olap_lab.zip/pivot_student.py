from pathlib import Path
import sqlite3
import pandas as pd

ROOT=Path(__file__).resolve().parent
with sqlite3.connect((ROOT/'data'/'warehouse.db').as_uri()+'?mode=ro',uri=True) as con:
    df=pd.read_sql_query('SELECT * FROM sales',con)

print("--- Data Preview ---")
print(df.head())

# TODO P1: province x month, sum(amount), fill_value=0, margins=True
P1 = df.pivot_table(
    index="province", 
    columns="month", 
    values="amount", 
    aggfunc="sum", 
    fill_value=0, 
    margins=True,
    margins_name="Total"
)
print("\n--- P1: Province x Month ---")
print(P1)

# TODO P2: filter September, then category x province
df_sep = df[df["month"] == "2026-09"]
P2 = df_sep.pivot_table(
    index="category", 
    columns="province", 
    values="amount", 
    aggfunc="sum", 
    fill_value=0
)
print("\n--- P2: Category x Province (September) ---")
print(P2)

# TODO P3: assert that the pivot grand total equals df['amount'].sum()
# เลือกเฉพาะเซลล์แถว Total และคอลัมน์ Total มาเทียบกับผลรวมทั้งหมด
grand_total = P1.loc["Total", "Total"]
assert grand_total == df["amount"].sum(), f"Mismatch: Pivot={grand_total}, DF={df['amount'].sum()}"
print(f"\n✅ Assert Passed: ยอดรวมแกรนด์โททัลตรงกัน ({grand_total} บาท)")

# TODO P4: export each result to CSV in your submission folder
P1.to_csv(ROOT / "pivot_province_month.csv")
P2.to_csv(ROOT / "pivot_september.csv")
print("✅ บันทึกไฟล์ pivot_province_month.csv และ pivot_september.csv เรียบร้อยแล้ว")