SELECT 
    (SELECT COUNT(*) FROM fact_sales) AS fact_rows,
    (SELECT SUM(quantity * unit_price) FROM fact_sales) AS fact_revenue,
    (SELECT COUNT(*) FROM sales) AS sales_rows,
    (SELECT SUM(amount) FROM sales) AS sales_revenue;